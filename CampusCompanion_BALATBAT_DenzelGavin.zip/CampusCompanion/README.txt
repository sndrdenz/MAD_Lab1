Campus Companion - Laboratory Exercise 2
BALATBAT, DENZEL GAVIN

OPEN AND RUN
1. Extract this ZIP completely.
2. Open CampusCompanion.xcodeproj in Xcode.
3. Select the CampusCompanion scheme and an iPhone Simulator.
4. Press Command-R.

The project retains the starter's Xcode 26.1 project settings and iOS 26.1
deployment target. Use Xcode 26.1 or newer with a compatible iOS Simulator.

INCLUDED
The original project has been repaired and completed through Part 3.
The interface follows Figure 10: the name field, notification switch, role
control, event date, guest stepper, and Explore Campus button. The second
screen displays all five captured values with a working navigation Back button.

Defaults: Student for a blank or whitespace-only name, notifications off,
Student role, today's date, and 0 guests. The guest stepper supports 0-100.
All Swift creator comments use BALATBAT, DENZEL GAVIN.

CHECK IN THE SIMULATOR
- Enter Juan, turn notifications on, select Faculty, choose October 15, 2026,
  and increase guests to 3. Tap Explore Campus. The result should read:

  Welcome, Juan! (Faculty)
  Notifications: on.
  Event: Oct 15, 2026
  Guests: 3

  The date's wording follows the Simulator's region settings.
- Tap Back. The entered values should remain on the welcome screen.
- Clear the name and try again. The displayed name should be Student.
- Tap Done on the keyboard to dismiss it, or tap Explore Campus to dismiss
  the keyboard and navigate. On smaller screens, scroll to reach the button.

VALIDATION
Source and storyboard connections were checked, but Xcode and the iOS
Simulator were unavailable in the editing environment. A native build and
Simulator run still need to be performed on a Mac.
