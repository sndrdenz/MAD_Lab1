//
//  ViewController.swift
//  CampusCompanion
//
//  Created by BALATBAT, DENZEL GAVIN on 9/12/26.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var formScrollView: UIScrollView!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var notifySwitch: UISwitch!
    @IBOutlet weak var roleSegmentedControl: UISegmentedControl!
    @IBOutlet weak var eventDatePicker: UIDatePicker!
    @IBOutlet weak var guestStepper: UIStepper!
    @IBOutlet weak var guestCountLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Campus Companion"
        navigationItem.backButtonTitle = "Back"
        eventDatePicker.preferredDatePickerStyle = .compact
        eventDatePicker.date = Date()
        updateGuestCountLabel()

        // Keep the form scrollable when the keyboard covers a smaller screen.
        formScrollView.bottomAnchor.constraint(
            lessThanOrEqualTo: view.keyboardLayoutGuide.topAnchor
        ).isActive = true
    }

    @IBAction func exploreButtonTapped(_ sender: UIButton) {
        nameTextField.resignFirstResponder()
        performSegue(withIdentifier: "ShowDetailSegue", sender: self)
    }

    @IBAction func nameEditingDidEndOnExit(_ sender: UITextField) {
        sender.resignFirstResponder()
    }

    @IBAction func guestStepperChanged(_ sender: UIStepper) {
        updateGuestCountLabel()
    }

    private func updateGuestCountLabel() {
        guestCountLabel.text = "Number of Guests: \(Int(guestStepper.value))"
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "ShowDetailSegue",
              let destination = segue.destination as? DetailViewController else {
            return
        }

        let enteredName = (nameTextField.text ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        destination.studentName = enteredName.isEmpty ? "Student" : enteredName
        destination.notificationsEnabled = notifySwitch.isOn
        destination.selectedRole = roleSegmentedControl.selectedSegmentIndex == 0
            ? "Student" : "Faculty"
        destination.preferredEventDate = eventDatePicker.date
        destination.numberOfGuests = Int(guestStepper.value)
    }
}
