//
//  DetailViewController.swift
//  CampusCompanion
//
//  Created by BALATBAT, DENZEL GAVIN on 9/19/26.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var messageLabel: UILabel!

    var studentName: String = "Student"
    var notificationsEnabled: Bool = false
    var selectedRole: String = "Student"
    var preferredEventDate: Date = Date()
    var numberOfGuests: Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Campus Events"

        let notificationStatus = notificationsEnabled ? "on" : "off"
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .none
        let eventDate = dateFormatter.string(from: preferredEventDate)

        messageLabel.text = """
        Welcome, \(studentName)! (\(selectedRole))
        Notifications: \(notificationStatus).
        Event: \(eventDate)
        Guests: \(numberOfGuests)
        """
    }
}
