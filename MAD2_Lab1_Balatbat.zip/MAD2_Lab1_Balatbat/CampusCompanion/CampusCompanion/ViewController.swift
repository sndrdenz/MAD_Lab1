//
//  ViewController.swift
//  CampusCompanion
//
//  Created by DENZEL GAVIN BALATBAT on 9/12/26.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel.text = "Campus Companion"
        // Provide a default subtitle if none is set in Interface Builder.
        if subtitleLabel.text?.isEmpty ?? true {
            subtitleLabel.text = "Your campus companion awaits."
        }
    }

    @IBAction func didTapGetStarted(_ sender: UIButton) {
        subtitleLabel.text = "Let's get started!"
    }

}
